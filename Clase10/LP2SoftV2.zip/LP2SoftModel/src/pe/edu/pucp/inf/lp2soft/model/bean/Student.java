package pe.edu.pucp.inf.lp2soft.model.bean;
public class Student extends Person{
    private float CRAEST;

    public Student(){
        
    }
    
    public Student(String firstName, int age, float CRAEST){
        super(firstName,age);
        this.CRAEST = CRAEST;
    }
    
    public Student(int idStudent, String firstName, int age, float CRAEST) {
        super(idStudent,firstName, age);
        this.CRAEST = CRAEST;
    }

    public float getCRAEST() {
        return CRAEST;
    }

    public void setCRAEST(float CRAEST) {
        this.CRAEST = CRAEST;
    }
}
