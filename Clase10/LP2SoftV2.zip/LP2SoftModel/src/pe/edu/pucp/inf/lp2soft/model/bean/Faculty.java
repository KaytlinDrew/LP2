package pe.edu.pucp.inf.lp2soft.model.bean;

import java.util.ArrayList;

public class Faculty {
    private int idFaculty;
    private String name;
    private ArrayList<Career> careers;
}
