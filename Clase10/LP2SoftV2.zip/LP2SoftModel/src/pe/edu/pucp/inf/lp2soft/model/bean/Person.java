package pe.edu.pucp.inf.lp2soft.model.bean;

public class Person {
    private int idPerson;
    private String firstName;
    private int age;

    public Person(){
        
    }
    
    public Person(int idPerson, String firstName, int age){
        this.idPerson = idPerson;
        this.firstName = firstName;
        this.age = age;
    }
    
    public Person(String firstName, int age){
        this.firstName = firstName;
        this.age = age;
    }
    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public int getIdPerson() {
        return idPerson;
    }

    public void setIdPerson(int idPerson) {
        this.idPerson = idPerson;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
