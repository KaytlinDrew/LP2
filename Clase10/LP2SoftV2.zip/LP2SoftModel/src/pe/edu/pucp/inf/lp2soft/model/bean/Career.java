package pe.edu.pucp.inf.lp2soft.model.bean;
public class Career {
    private String idCareer;
    
}
