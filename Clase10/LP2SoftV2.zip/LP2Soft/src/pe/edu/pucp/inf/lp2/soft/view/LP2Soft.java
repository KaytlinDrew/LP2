package pe.edu.pucp.inf.lp2.soft.view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import pe.edu.pucp.inf.lp2soft.dao.DAOStudent;
import pe.edu.pucp.inf.lp2soft.model.bean.Student;
import pe.edu.pucp.inf.lp2soft.mysql.MySQLStudent;

public class LP2Soft {
    public static void main(String[] args) {
        int rpta;
        BufferedReader teclado= new BufferedReader(new InputStreamReader(System.in));
        DAOStudent daoStudent = new MySQLStudent();
        try{
            do{
                System.out.println("===========================");
                System.out.println("1. Listar Estudiantes");
                System.out.println("2. Registrar Estudiante");
                System.out.println("3. Salir");
                System.out.println("===========================");
                System.out.print("Ingrese opcion: ");
                rpta = Integer.parseInt(teclado.readLine());
                switch(rpta){
                    case 1: 
                        ArrayList<Student> students = daoStudent.queryAll();
                        for(Student s : students){
                            System.out.println(s.getIdPerson()+" "+s.getFirstName()+" "+s.getAge()+" "+s.getCRAEST());
                        }
                        break;
                    case 2:
                        System.out.print("Ingrese el nombre: ");
                        String name = teclado.readLine();
                        System.out.print("Ingrese la edad: ");
                        int age = Integer.parseInt(teclado.readLine());
                        System.out.print("Ingrese el CRAEST: ");
                        float CRAEST = Float.parseFloat(teclado.readLine());
                        Student s = new Student(name,age,CRAEST);
                        if (daoStudent.insert(s) == 1)
                            System.out.println("Se ha registrado con exito");
                        break;
                }
            }while(rpta!=3);
        }catch(IOException | NumberFormatException ex){
            System.out.println("Ha ocurrido una excepcion...");
            System.out.println(ex.getMessage());
            System.out.println("El programa ha finalizado con errores...");
        }
    }
}
