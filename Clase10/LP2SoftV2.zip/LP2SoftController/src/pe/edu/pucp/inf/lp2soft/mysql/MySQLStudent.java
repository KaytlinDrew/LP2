package pe.edu.pucp.inf.lp2soft.mysql;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import pe.edu.pucp.inf.lp2soft.config.DBManager;
import pe.edu.pucp.inf.lp2soft.dao.DAOStudent;
import pe.edu.pucp.inf.lp2soft.model.bean.Student;
public class MySQLStudent implements DAOStudent{

    @Override
    public int insert(Student student) {
        int result = 0;
        try{
            DBManager dbManager = DBManager.getDbManager();
            Connection con = DriverManager.getConnection(dbManager.getUrl(), dbManager.getUser(), dbManager.getPassword());
            String sql = "INSERT INTO STUDENT(FIRST_NAME,AGE,CRAEST) VALUES(?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, student.getFirstName());
            ps.setInt(2, student.getAge());
            ps.setFloat(3, student.getCRAEST());
            result = ps.executeUpdate();
            con.close();
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }
    return result;
    }

    @Override
    public int update(Student student) {
        int result = 0;
        try{
            DBManager dbManager = DBManager.getDbManager();
            Connection con = DriverManager.getConnection(dbManager.getUrl(), dbManager.getUser(), dbManager.getPassword());
            CallableStatement cs = con.prepareCall("{call UPDATE_STUDENT(?,?,?,?)}");
            cs.setInt(1, student.getIdPerson());
            cs.setString(2, student.getFirstName());
            cs.setInt(3, student.getAge());
            cs.setFloat(4, student.getCRAEST());
            result = cs.executeUpdate();
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }
        return result;
    }

    @Override
    public int delete(int idStudent) {
        return 0;
    }

    @Override
    public ArrayList<Student> queryAll() {
        ArrayList<Student> listStudents = new ArrayList<Student>();
        try{
            DBManager dbManager = DBManager.getDbManager();
            Connection con = DriverManager.getConnection(dbManager.getUrl(), dbManager.getUser(), dbManager.getPassword());
            CallableStatement cs = con.prepareCall("{call LIST_STUDENTS()}");
            ResultSet rs = cs.executeQuery();
            while(rs.next()){
                Student student = new Student();
                student.setIdPerson(rs.getInt("ID_STUDENT"));
                student.setFirstName(rs.getString("FIRST_NAME"));
                student.setAge(rs.getInt("AGE"));
                student.setCRAEST(rs.getFloat("CRAEST"));
                listStudents.add(student);
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }
        return listStudents;
    }
    
}
