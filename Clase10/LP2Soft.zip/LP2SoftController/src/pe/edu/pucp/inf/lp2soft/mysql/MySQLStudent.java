package pe.edu.pucp.inf.lp2soft.mysql;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import pe.edu.pucp.inf.lp2soft.config.DBManager;
import pe.edu.pucp.inf.lp2soft.dao.DAOStudent;
import pe.edu.pucp.inf.lp2soft.model.bean.Student;

public class MySQLStudent implements DAOStudent{

    @Override
    public int insert(Student student) {
        int result = 0;
        try{
            DBManager dbManager = DBManager.getDbManager();
            Connection con = DriverManager.getConnection(
            dbManager.getUrl(), 
            dbManager.getUser(), 
            dbManager.getPassword());
            String sql = "INSERT INTO STUDENT("
            + "FIRST_NAME,AGE,CRAEST) "
            + "VALUES(?,?,?)";
            PreparedStatement ps = 
                con.prepareStatement(sql);
            ps.setString(1, student.getFirstName());
            ps.setInt(2, student.getAge());
            ps.setFloat(3, student.getCRAEST());
            result = ps.executeUpdate();
            con.close();
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    return result;
    }

    @Override
    public int update(Student student) {
        int result = 0;
        try{
            DBManager dbManager = DBManager.getDbManager();
            Connection con = DriverManager.getConnection(
            dbManager.getUrl(), 
            dbManager.getUser(), 
            dbManager.getPassword());
            CallableStatement cs = con.prepareCall(""
                    + "{call UPDATE_STUDENT(?,?,?,?)}");
            cs.setInt(1, student.getIdStudent());
            cs.setString(2, student.getFirstName());
            cs.setInt(3, student.getAge());
            cs.setFloat(4, student.getCRAEST());
            result = cs.executeUpdate();
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        return result;
    }

    @Override
    public int delete(int idStudent) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Student> queryAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
