package pe.edu.pucp.inf.lp2.soft.view;

import pe.edu.pucp.inf.lp2soft.dao.DAOStudent;
import pe.edu.pucp.inf.lp2soft.model.bean.Student;
import pe.edu.pucp.inf.lp2soft.mysql.MySQLStudent;

public class LP2Soft {
    public static void main(String[] args) {
        Student s1 = new Student();
        s1.setIdStudent(2);
        s1.setFirstName("Laura");
        s1.setAge(32);
        s1.setCRAEST(71.2f);
        DAOStudent daoStudent = new MySQLStudent();
        daoStudent.update(s1);
    }
}
