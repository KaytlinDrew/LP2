package pe.edu.pucp.inf.lp2soft.model.bean;
public class Student {
    private int idStudent;
    private String firstName;
    private int age;
    private float CRAEST;

    public int getIdStudent() {
        return idStudent;
    }

    public void setIdStudent(int idStudent) {
        this.idStudent = idStudent;
    }

    
    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public float getCRAEST() {
        return CRAEST;
    }

    public void setCRAEST(float CRAEST) {
        this.CRAEST = CRAEST;
    }
    
}
